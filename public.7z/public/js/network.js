const ws = new WebSocket(`ws://${location.host}`);
let players={}, myId=null;
let myName = localStorage.getItem("playerName") || "Player";

ws.onmessage = e => {
  const data = JSON.parse(e.data);
  if(data.type==="chat"){
    addMessage(data.name+": "+data.msg);
    return;
  }
  if(data.type==="state"){
    myId=data.id;
    players=data.players;
  }
};

function sendState(state){
  ws.send(JSON.stringify({...state,name:myName}));
}

function sendChat(msg){
  ws.send(JSON.stringify({type:"chat",name:myName,msg}));
}