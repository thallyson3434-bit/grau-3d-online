const scene=new THREE.Scene();
const camera=new THREE.PerspectiveCamera(75,innerWidth/innerHeight,0.1,1000);
const renderer=new THREE.WebGLRenderer({antialias:true});
renderer.setSize(innerWidth,innerHeight);
document.body.appendChild(renderer.domElement);

const ground=new THREE.Mesh(new THREE.PlaneGeometry(200,200),
new THREE.MeshBasicMaterial({color:0x444444}));
ground.rotation.x=-Math.PI/2;
scene.add(ground);

camera.position.set(0,6,10);
const motos={},labels={};

function animate(){
 requestAnimationFrame(animate);

 if(myId&&players[myId]){
  const me=players[myId];
  if(input.forward)me.z-=0.2;
  if(input.grau)me.angle+=0.04;
  else me.angle-=0.03;
  me.angle=Math.max(-0.3,Math.min(1.2,me.angle));
  sendState(me);
  camera.position.x=me.x;
  camera.position.z=me.z+10;
  camera.lookAt(me.x,0,me.z);
 }

 for(let id in players){
  if(!motos[id]){
   motos[id]=new THREE.Mesh(new THREE.BoxGeometry(2,.5,1),
   new THREE.MeshBasicMaterial({color:id===myId?0xffff00:0xff0000}));
   scene.add(motos[id]);

   const c=document.createElement("canvas");
   c.width=256;c.height=64;
   const ctx=c.getContext("2d");
   const tex=new THREE.CanvasTexture(c);
   const spr=new THREE.Sprite(new THREE.SpriteMaterial({map:tex}));
   spr.scale.set(3,.8,1);
   scene.add(spr);
   labels[id]={c,ctx,tex,spr};
  }
  motos[id].position.set(players[id].x,.5,players[id].z);
  motos[id].rotation.z=players[id].angle;

  const l=labels[id];
  l.ctx.clearRect(0,0,256,64);
  l.ctx.fillStyle="white";
  l.ctx.font="30px Arial";
  l.ctx.textAlign="center";
  l.ctx.fillText(players[id].name,128,40);
  l.tex.needsUpdate=true;
  l.spr.position.set(players[id].x,2,players[id].z);
 }

 renderer.render(scene,camera);
}
animate();