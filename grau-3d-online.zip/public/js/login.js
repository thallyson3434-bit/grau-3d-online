function login(){
 const n=document.getElementById("nameInput").value.trim();
 if(!n)return alert("Digite um nome");
 localStorage.setItem("playerName",n);
 document.getElementById("login").style.display="none";
}