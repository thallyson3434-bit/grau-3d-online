let input={forward:false,grau:false};

document.addEventListener("keydown",e=>{
 if(e.key==="w")input.forward=true;
 if(e.code==="Space")input.grau=true;
});
document.addEventListener("keyup",e=>{
 if(e.key==="w")input.forward=false;
 if(e.code==="Space")input.grau=false;
});
document.addEventListener("touchstart",e=>{
 if(e.touches[0].clientX<innerWidth/2)input.forward=true;
 else input.grau=true;
});
document.addEventListener("touchend",()=>{input.forward=false;input.grau=false;});