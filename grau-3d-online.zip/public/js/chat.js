const inputChat=document.getElementById("chatInput");
const messages=document.getElementById("messages");

inputChat.addEventListener("keydown",e=>{
 if(e.key==="Enter"&&inputChat.value){
  sendChat(inputChat.value);
  inputChat.value="";
 }
});

function addMessage(t){
 const d=document.createElement("div");
 d.textContent=t;
 messages.appendChild(d);
 messages.scrollTop=messages.scrollHeight;
}