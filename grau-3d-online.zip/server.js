const express = require("express");
const http = require("http");
const WebSocket = require("ws");

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.static("public"));

let players = {};
let sockets = {};

wss.on("connection", ws => {
  const id = Date.now().toString();
  sockets[id] = ws;

  players[id] = { x:0, z:0, angle:0, name:"Player" };

  ws.on("message", msg => {
    const data = JSON.parse(msg);
    if(data.type === "chat"){
      for(let s in sockets){
        sockets[s].send(JSON.stringify(data));
      }
      return;
    }
    players[id] = { ...players[id], ...data };
  });

  ws.on("close", ()=>{
    delete players[id];
    delete sockets[id];
  });

  setInterval(()=>{
    ws.send(JSON.stringify({ type:"state", id, players }));
  },40);
});

server.listen(3000, ()=>console.log("Servidor online"));